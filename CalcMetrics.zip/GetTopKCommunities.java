import java.awt.List;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;

public class GetTopKCommunities {

	public static void main(String[] args) throws IOException {
		
		System.out.println("g");
		UndirectedUnweightedGraph g = new UndirectedUnweightedGraph(Paths.get("C:/Users/t-amirub/Desktop/amazon/com-amazon.ungraph.txt"));		
		//UndirectedUnweightedGraph g = new UndirectedUnweightedGraph(Paths.get("C:/Users/t-amirub/Desktop/amazon/net.txt"));
		System.out.println("metaData");
		CommunitiesMetaData metaData = new CommunitiesMetaData(g,"C:/Users/t-amirub/Desktop/amazon/com-amazon.all.cmty.txt");
		//CommunitiesMetaData metaData = new CommunitiesMetaData(g,"C:/Users/t-amirub/Desktop/amazon/comm.txt");
		
		System.out.println("Conductance");
		SortedSet<Entry<Integer, Double>> Conductance = CalcMetrics.Conductance(metaData);
		
		Map<Integer, Integer> ConductanceRank = sortedSetToMappingOfRanks(Conductance);
		
		System.out.println("FlakeODF");
		SortedSet<Entry<Integer, Double>> FlakeODF = CalcMetrics.FlakeODF(metaData);
		Map<Integer, Integer> FlakeODFRank = sortedSetToMappingOfRanks(FlakeODF);
		
		System.out.println("FOMD");
		SortedSet<Entry<Integer, Double>> FOMD = CalcMetrics.FOMD(metaData);
		Map<Integer, Integer> FOMDRank = sortedSetToMappingOfRanks(FOMD);
		
		System.out.println("TPM");
		SortedSet<Entry<Integer, Double>> TPM = CalcMetrics.TPM(metaData);
		Map<Integer, Integer> TPMRank = sortedSetToMappingOfRanks(TPM);
		
		System.out.println("CutRatio");
		SortedSet<Entry<Integer, Double>> CutRatio = CalcMetrics.CutRatio(metaData);
		Map<Integer, Integer> CutRatioRank = sortedSetToMappingOfRanks(CutRatio);
		
		System.out.println("Modularity");
		SortedSet<Entry<Integer, Double>> Modularity = CalcMetrics.Modularity(metaData);
		Map<Integer, Integer> ModularityRank = sortedSetToMappingOfRanks(Modularity);
		
		System.out.println("sumMetrics");
		Map<Integer, Integer> SumRank = SumRank(ConductanceRank, FlakeODFRank, FOMDRank, TPMRank, CutRatioRank, ModularityRank);
		System.out.println("top1517");
		int k = 1517;
		Map<Integer, Set<Integer>> topK = GetTopK(SumRank, k, metaData.com2nodes);
		System.out.println("WriteToFile");
		WriteToFile(topK, "C:/Users/t-amirub/Desktop/amazon/com-amazon.myTop1517ByRank.txt");
		System.out.println("top5000");
		k = 5000;
		topK = GetTopK(SumRank, k, metaData.com2nodes);
		System.out.println("WriteToFile");
		WriteToFile(topK, "C:/Users/t-amirub/Desktop/amazon/com-amazon.myTop5000ByRank.txt");
	}


	public static Map<Integer, Integer> sortedSetToMappingOfRanks (SortedSet<Entry<Integer, Double>> sorted){
		Map<Integer, Integer> ans = new HashMap<>();
		Iterator<Entry<Integer, Double>> iter = sorted.iterator();
		int size = sorted.size();
		int commId;
		while (iter.hasNext()){
			commId = iter.next().getKey();
			ans.put(commId, size);
			size--;
		}
		return ans;
	}
	
	private static Map<Integer, Set<Integer>> GetTopK(Map<Integer, Integer> SumRank, int k, Map<Integer, Set<Integer>> com2nodes) {
		if(com2nodes.size()<k){
			return com2nodes;
		}
		
		Map<Integer, Set<Integer>> ans = new HashMap<>();
		ArrayList<Integer> list = new ArrayList<Integer>(SumRank.values());
		Collections.sort(list);
		double kthValue = list.get(k);
		for(Entry<Integer, Integer> commIdAndSum : SumRank.entrySet()){			
			int commId= commIdAndSum.getKey();
			if(commIdAndSum.getValue()<=kthValue){
				ans.put(commId, com2nodes.get(commId));
			}
		}		
		return ans;
	}

	private static Map<Integer, Integer> SumRank(Map<Integer, Integer> conductance, Map<Integer, Integer> flakeODF,
			Map<Integer, Integer> FOMD, Map<Integer, Integer> TPM, Map<Integer, Integer> cutRatio,
			Map<Integer, Integer> modularity) {
		Map<Integer, Integer> ans = new HashMap<>();
		for(Integer commId : conductance.keySet()){
			ans.put(commId, 
					conductance.get(commId) + flakeODF.get(commId) + FOMD.get(commId) + TPM.get(commId) + cutRatio.get(commId) + modularity.get(commId));
		}
		return ans;
	}

	private static void WriteToFile(Map<Integer, Set<Integer>> comms, String outputPath) throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter(outputPath , "UTF-8");
		for ( Set<Integer> listOfNodes : comms.values()){
			if(listOfNodes.size()>0){
				for(int node : listOfNodes){
					writer.print(node + " ");
				}
				writer.println("");
			}
		}		
		writer.close();	
	}
}

